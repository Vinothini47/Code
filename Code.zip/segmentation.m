
% segmentation.m
function mask = segmentation(preprocessed_image)
    % Mock segmentation using simple threshold (replace with real model output)
    mask = imbinarize(preprocessed_image.blurred);
end
