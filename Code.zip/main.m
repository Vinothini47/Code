
% main.m
clc; clear; close all;

% Load image
image = imread('sample_ct_scan.png');

% Step 1: Preprocessing
preprocessed = preprocessing(image);

% Step 2: Segmentation
mask = segmentation(preprocessed);

% Step 3: Severity Prediction
[severity, severity_percent] = severity_prediction(mask, preprocessed.gray);

% Step 4: GJS Optimization (placeholder)
best_params = gjs_optimization();
