
% preprocessing.m
function preprocessed = preprocessing(input_image)
    gray_image = rgb2gray(input_image);
    denoised_image = medfilt2(gray_image);
    threshold = graythresh(denoised_image);
    binary_image = imbinarize(denoised_image, threshold);
    reverse_colored = imcomplement(denoised_image);
    gaussian_blurred = imgaussfilt(denoised_image, 2);
    flipped_image = fliplr(denoised_image);
    preprocessed = struct('gray', gray_image, 'denoised', denoised_image, ...
        'binary', binary_image, 'reverse', reverse_colored, ...
        'blurred', gaussian_blurred, 'flipped', flipped_image);
end
