
% severity_prediction.m
function [severity, severity_percent] = severity_prediction(mask, original_image)
    props = regionprops(mask, 'BoundingBox', 'Area');
    total_area = numel(mask);
    infected_area = sum(mask(:));
    severity_percent = (infected_area / total_area) * 100;

    if severity_percent == 0
        severity = 'Healthy';
    elseif severity_percent <= 25
        severity = 'Mild';
    elseif severity_percent <= 50
        severity = 'Moderate';
    elseif severity_percent <= 75
        severity = 'Severe';
    else
        severity = 'Critical';
    end

    % Visualize
    figure; imshow(original_image); title(['Severity: ', severity]);
    hold on;
    for i = 1:length(props)
        rectangle('Position', props(i).BoundingBox, 'EdgeColor', 'r', 'LineWidth', 2);
    end
    hold off;
end
